﻿
public class utf8bom {
    public static void main(String[] args) {
    }
}

